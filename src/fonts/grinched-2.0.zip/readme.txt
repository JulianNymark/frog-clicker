TrueTypeFont: Grinched 2.0
Dennis Ludlow 2015 all rights reserved
Sharkshock Productions
dennis@sharkshock.net


Hi Everyone, thanks for taking a look! Grinched was my most popular font by far and after several years in need of some updating. After some tweaking here and there the decision was made to
completely redo the font keeping several of the original characters intact. 80% of the uppercase letters have made their way back into the new version while 95% of the lowercase letters were
replaced and redrawn completely. Each glyph was carefully re-edited for maximum sharpness and magnification at large sizes. This is the first of my fonts that covers many new languages 
previously not found in any of the others. Cyrillic characters were added for Russian and Ukranian users. Glyphs have been added for Portugeuse, Spanish, Serbian, Czech, and several other
Central and East European countries. There are 676 glyphs in all! Full punctuation and kerning (strategic spacing between letters) was added to standard latin used in English. Letters are 
intentionally closer together than the previous version. 


This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license.
If you've previously licensed the older version you're grandfathered into this version. Thank you! I also design custom fonts for businesses, logos, and many other things. If you'd like to 
leave me a donation you can use the same address via paypal. Your generosity will be most appreciated!


visit www.sharkshock.net for more and take a bite out of BORING design!

